import pandas as pd               
import numpy as np
import pickle


# ####  Read new data

input_array=np.array([[332,108,3,4,4.5,8.75,1]])

# Loading the model pickle
lm_model_pkl = open("lm_model.pkl", 'rb')
lm_model = pickle.load(lm_model_pkl)
print("Model coefficients:  ",lm_model.coef_)

# ###  Predict on new data
y_pred=lm_model.predict(input_array)
print("Predicted House price:",y_pred)


